import React, { useEffect, useRef, useState } from 'react';
import {
  IonAvatar,
  IonContent,
  IonHeader,
  IonIcon,
  IonItem,
  IonItemOptions,
  IonItemOption,
  IonItemSliding,
  IonLabel,
  IonList,
  IonTitle,
  IonToolbar,
  IonAccordionGroup,
  IonAccordion,
  IonCardContent,
  IonButton,
  IonAlert,
  IonModal,
  IonTextarea,
  IonToast,
  IonButtons,
  IonText,
} from '@ionic/react';
import { chatbubbleEllipses, helpCircle, lockClosed, pin, settings, share, trash } from 'ionicons/icons';
import './Profile.css';
import './Notification.css';
import { camera } from 'ionicons/icons';
import { close, sendOutline } from 'ionicons/icons';
function Example() {
  const [user, setUser] = useState(null);
  const [image, setImage] = useState(null); // Preview da imagem ou avatar selecionado
  const [selectedFile, setSelectedFile] = useState(null); // Arquivo selecionado (upload)
  const [selectedAvatar, setSelectedAvatar] = useState(null); // Avatar selecionado (URL)
  const [showOptions, setShowOptions] = useState(false);
  const [showAvatars, setShowAvatars] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [feedback, setFeedback] = useState('');
  const [toastMessage, setToastMessage] = useState('');
  const [showToast, setShowToast] = useState(false);

  // Ref para o input de arquivo
  const fileInputRef = useRef(null);

  const avatars = [
    'https://phapp.phng.com.br/storage/profile_images/avatars/Avatar1.png',
    'https://phapp.phng.com.br/storage/profile_images/avatars/Avatar2.png',
    'https://phapp.phng.com.br/storage/profile_images/avatars/Avatar3.png',
  ];

  const handleSubmit = async () => {
    if (!feedback.trim()) {
      alert('Por favor, digite seu feedback.');
      return;
    }

    try {
      const response = await fetch('https://phapp.phng.com.br/api/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: feedback }),
      });

      if (response.ok) {
        setFeedback('');
        setToastMessage('Feedback enviado com sucesso!');
        setShowModal(false);
      } else {
        setToastMessage('Erro ao enviar feedback.');
        alert('Erro ao enviar feedback.');
      }
    } catch (error) {
      console.error('Erro:', error);
      setToastMessage('Erro ao conectar com o servidor.');

    }
    setShowToast(true);

  };

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("Token não encontrado!");
          return;
        }
        const response = await fetch("https://phapp.phng.com.br/api/user", {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });
        if (response.ok) {
          const data = await response.json();
          setUser(data);
          localStorage.setItem("dadosUsuario", JSON.stringify(data));
        } else {
          throw new Error("Falha ao carregar os dados do usuário");
        }
      } catch (error) {
        console.error("Erro ao buscar dados do usuário:", error);
      }
    };

    fetchUser();
  }, []);

  // Quando o usuário seleciona um arquivo para upload
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      setSelectedAvatar(null); // Limpa eventual avatar selecionado
      setImage(URL.createObjectURL(file));
    }
  };

  // Quando o usuário escolhe um avatar da lista
  const handleAvatarSelection = (avatar) => {
    setSelectedAvatar(avatar);
    setSelectedFile(null); // Limpa eventual arquivo selecionado
    setImage(avatar); // Mostra o avatar como preview
    setShowAvatars(false);
  };

  // Handler unificado para atualizar a foto (arquivo ou avatar)
  const handleUpdateImage = async () => {
    const token = localStorage.getItem("token");

    // Se um arquivo foi selecionado, realiza o upload via FormData
    if (selectedFile) {
      const formData = new FormData();
      formData.append('image', selectedFile);
      formData.append('pessoa_hash', user.pessoa_hash);
      try {
        const response = await fetch('https://phapp.phng.com.br/api/upload-profile-image', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          body: formData,
        });
        if (response.ok) {
          const data = await response.json();
          setUser((prevUser) => ({ ...prevUser, pessoa_image: data.image }));
          // Limpa os estados após o upload
          setImage(null);
          setSelectedFile(null);
        } else {
          const data = await response.json();
          console.error('Erro ao enviar imagem', data);
        }
      } catch (error) {
        console.error('Erro ao enviar a imagem:', error);
      }
    }
    // Se um avatar foi selecionado, atualiza via endpoint específico
    else if (selectedAvatar) {
      try {
        // Atenção: a chave enviada deve ser "avatar" e não "image"
        const response = await fetch('https://phapp.phng.com.br/api/upload-profile-avatar', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            pessoa_hash: user.pessoa_hash,
            avatar: selectedAvatar
          })
        });
        if (response.ok) {
          const data = await response.json();
          setUser((prevUser) => ({ ...prevUser, pessoa_image: selectedAvatar }));
          setSelectedAvatar(null);
          setImage(null);
        } else {
          const data = await response.json();
          console.error('Erro ao atualizar avatar', data);
        }
      } catch (error) {
        console.error('Erro ao atualizar avatar:', error);
      }
    }
  };


  return (
    <>
      <IonHeader>
        {/*
        <IonToolbar>
          <IonTitle>Perfil</IonTitle>
        </IonToolbar>
        */}
      </IonHeader>
      <IonContent>
        <IonToast
          isOpen={showToast}
          onDidDismiss={() => setShowToast(false)}
          message={toastMessage}
          duration={3000}
          position="top"
          color={toastMessage.includes('sucesso') ? 'success' : 'danger'}
        />
        <IonList inset={true} style={{ margin: '0', padding: '0px' }}>
          <img src='/Rectangle 2.png' style={{ width: '100%' }} />
          <div className='profile-header' style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', marginTop: '-70px', marginLeft: '15px' }}>
            {/* Input de arquivo oculto */}
            <input
              type='file'
              accept='image/*'
              style={{ display: 'none' }}
              id='file-input'
              ref={fileInputRef}
              onChange={handleImageChange}
            />
            {/* Ao clicar na imagem, abre as opções */}
            <label onClick={() => setShowOptions(true)} style={{ cursor: 'pointer' }}>
              <img
                src={
                  image
                    ? image
                    : user?.pessoa_image
                      ? user.pessoa_image.startsWith('http')
                        ? user.pessoa_image
                        : `https://phapp.phng.com.br/storage/profile_images/${user.pessoa_image}`
                      : 'https://phapp.phng.com.br/storage/profile_images/1738760051.png'
                }
                alt="Foto do Perfil"
                style={{ width: '140px', borderRadius: '100%', height: '140px' }}
              />
              <IonIcon icon={camera} />
            </label>
          </div>
          <div className='profile-info' style={{ marginTop: '-20px' }}>
            <div style={{ display: 'flex', flexDirection: 'row', gap: '5px', alignItems: 'center', justifyContent: 'center' }}>
              <h1 style={{ marginTop: '10px', color: '#0F1419', fontFamily: 'Roboto', fontSize: '22px', fontStyle: 'normal', fontWeight: '700', lineHeight: '19px' }}>{user ? user.name : 'Meu perfil'}</h1>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M18.5243 9.98997C18.5087 9.43206 18.3386 8.88883 18.032 8.42161C17.7263 7.95524 17.2962 7.58215 16.7901 7.34552C16.9827 6.82129 17.0233 6.25388 16.911 5.7072C16.7978 5.15965 16.5336 4.65529 16.1493 4.25024C15.7433 3.86593 15.2398 3.60252 14.6923 3.48852C14.1456 3.37624 13.5782 3.41683 13.054 3.60943C12.8182 3.10247 12.446 2.67152 11.9788 2.36579C11.5115 2.06006 10.9683 1.88906 10.4095 1.87524C9.85162 1.88993 9.31012 2.0592 8.84375 2.36579C8.37739 2.67238 8.00689 3.10333 7.77285 3.60943C7.24775 3.41683 6.67862 3.37452 6.13021 3.48852C5.5818 3.60079 5.07657 3.86506 4.67066 4.25024C4.28635 4.65615 4.0238 5.16138 3.91239 5.70806C3.80012 6.25474 3.8433 6.82215 4.03675 7.34552C3.5298 7.58215 3.09798 7.95438 2.79053 8.42074C2.48307 8.88711 2.31121 9.4312 2.2948 9.98997C2.31207 10.5487 2.48307 11.092 2.79053 11.5592C3.09798 12.0256 3.5298 12.3987 4.03675 12.6344C3.8433 13.1578 3.80012 13.7252 3.91239 14.2719C4.02466 14.8194 4.28635 15.3238 4.6698 15.7297C5.07571 16.1123 5.58007 16.3748 6.12675 16.488C6.67344 16.602 7.24085 16.5605 7.76507 16.3705C8.00171 16.8766 8.37394 17.3067 8.84116 17.6133C9.30753 17.919 9.85162 18.0892 10.4095 18.1047C10.9683 18.0909 11.5115 17.9207 11.9788 17.615C12.446 17.3093 12.8182 16.8775 13.054 16.3714C13.5756 16.5778 14.1473 16.627 14.6975 16.513C15.2468 16.399 15.7511 16.127 16.1484 15.7297C16.5457 15.3324 16.8186 14.8281 16.9326 14.2779C17.0466 13.7278 16.9973 13.1561 16.7901 12.6344C17.2962 12.3978 17.7263 12.0256 18.0328 11.5583C18.3386 11.092 18.5087 10.5479 18.5243 9.98997ZM9.25398 13.315L6.29257 10.3544L7.40925 9.22997L9.19871 11.0194L12.9987 6.87915L14.162 7.95524L9.25398 13.315Z" fill="#F01D1D" />
              </svg>
            </div>
            <p style={{ marginTop: '-5px', marginLeft: '-10px', color: '#536471', fontFamily: 'Roboto', fontStyle: 'normal', fontWeight: '400', lineHeight: '19px', textAlign: 'center' }}>Detalhes</p>
          </div>
          <div style={{ display: 'flex', justifyContent: 'center' }}>

            {/* Exibe o botão "Atualizar Foto" se houver um arquivo ou avatar selecionado */}
            {(selectedFile || selectedAvatar) && (
              <button
                onClick={handleUpdateImage}
                style={{ background: '#d70404', width: '160px', padding: '7.5px 16px', borderRadius: '9999px', border: '1px solid #CC3636' }}
                className='custom-button-modal1'
              >
                Atualizar Foto
              </button>
            )}
          </div>

          {/* Alerta para escolher entre avatar e upload */}
          <IonAlert
            isOpen={showOptions}
            onDidDismiss={() => setShowOptions(false)}
            header={'Escolha uma opção'}
            buttons={[
              { text: 'Escolher Avatar', handler: () => setShowAvatars(true) },
              { text: 'Fazer Upload de Foto', handler: () => fileInputRef.current && fileInputRef.current.click() },
              { text: 'Cancelar', role: 'cancel' },
            ]}
          />

          {/* Exibe a lista de avatares para seleção */}
          {showAvatars && (
            <div className='avatar-selection' style={{ display: 'flex', gap: '10px', justifyContent: 'center', marginTop: '10px' }}>
              {avatars.map((avatar, index) => (
                <img
                  key={index}
                  src={avatar}
                  alt={`Avatar ${index + 1}`}
                  style={{ width: '60px', borderRadius: '50%', cursor: 'pointer' }}
                  onClick={() => handleAvatarSelection(avatar)}
                />
              ))}
            </div>
          )}

        </IonList>

        <IonList className="profile-options" style={{ background: '#EFEFEF', padding: '20px', marginTop: '20px' }}>
          {/* Seção FAQ */}
          <IonAccordionGroup style={{ padding: '10px' }}>
            <IonAccordion value="faq1" style={{ background: '#EFEFEF' }}>
              <IonItem slot="header">
                <IonLabel>Quem é a PH negócios?</IonLabel>
              </IonItem>
              <IonCardContent slot="content">
                A PH Negócios é uma fintech com autorização que excerce serviços de FGTS de forma segura e rápida!
              </IonCardContent>
            </IonAccordion>

            <IonAccordion value="faq2" style={{ background: '#EFEFEF' }}>
              <IonItem slot="header">
                <IonLabel>Estou tendo erros para antecipar?</IonLabel>
              </IonItem>
              <IonCardContent slot="content">
                A maioria dos erros são por conta de informações preenchidas incorretamente no formulário. Verifique se seus dados estão realmente corretos; caso persista, entre em contato conosco.
              </IonCardContent>
            </IonAccordion>

            <IonAccordion value="faq3" style={{ background: '#EFEFEF' }}>
              <IonItem slot="header">
                <IonLabel>Não recebeu o link do seu contrato?</IonLabel>
              </IonItem>
              <IonCardContent slot="content">
                Caso você não tenha recebido o link do seu contrato, você pode encontrá-lo na aba "meus contratos". Clicando em um dos contratos, você poderá verificar se seu contrato foi bem sucedido e pegar o link.
              </IonCardContent>
            </IonAccordion>
          </IonAccordionGroup>

        </IonList>

        <IonList style={{ padding: '20px', display: 'flex', flexWrap: 'wrap', gap: '20px', justifyContent: 'center' }}>
          {/*   <div style={{ display: 'flex', width: '155.5px', padding: '12px', flexDirection: 'column', alignItems: 'flex-start', gap: '8px', borderRadius: '8px', background: 'linear-gradient(180deg, rgba(207, 207, 207, 0.26) 0%, rgba(207, 207, 207, 0.00) 100%)'}}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', alignSelf: 'stretch'}}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignContent: 'center', width: '100%', height: 'auto'}}>
                <img src='saly-28.png' style={{ width: '30px'}}/>
                <div>
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                   <path d="M22.5 12C22.5 17.5229 18.0229 22 12.5 22C6.97714 22 2.5 17.5229 2.5 12C2.5 6.47714 6.97714 2 12.5 2C18.0229 2 22.5 6.47714 22.5 12ZM11.3433 17.2949L18.7627 9.87556C19.0146 9.62363 19.0146 9.21512 18.7627 8.96319L17.8503 8.05081C17.5983 7.79883 17.1898 7.79883 16.9379 8.05081L10.8871 14.1015L8.06214 11.2766C7.8102 11.0246 7.40169 11.0246 7.14972 11.2766L6.23734 12.189C5.9854 12.4409 5.9854 12.8494 6.23734 13.1013L10.4309 17.2949C10.6829 17.5469 11.0913 17.5469 11.3433 17.2949V17.2949Z" fill="#0CF73F"/>
                </svg>
                </div>
              </div>
              <h3 style={{marginTop: '-5px', alignSelf: 'stretch', color: '#262626', fontSize: '16px', fontFamily: 'Inter', fontStyle: 'normal', fontWeight: '600', lineHeight: '150%'}}>Consignado</h3>
              <p style={{ marginTop: '-10px', alignSelf: 'stretch', color: '#7A7A7A', fontFamily: 'Inter', fontSize: '16px', fontStyle: 'normal', fontWeight: '400', lineHeight: '150%'}}>National ID e tudo masi sobre</p>
              <button style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', alignSelf: 'stretch', borderRadius: '2222px', background: 'white', color: 'black', border: '1px solid red', padding: '4px 10px 4px 7px', height: '28px', fontSize: '13px', fontStyle: 'normal'}}>Saiba mais</button>
            </div>
          </div>

          <div style={{ display: 'flex', width: '155.5px', padding: '12px', flexDirection: 'column', alignItems: 'flex-start', gap: '8px', borderRadius: '8px', background: 'linear-gradient(180deg, rgba(207, 207, 207, 0.26) 0%, rgba(207, 207, 207, 0.00) 100%)'}}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', alignSelf: 'stretch'}}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignContent: 'center', width: '100%', height: 'auto'}}>
                <img src='Saly-21.png' style={{ width: '30px'}}/>
                <div>
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                   <path d="M22.5 12C22.5 17.5229 18.0229 22 12.5 22C6.97714 22 2.5 17.5229 2.5 12C2.5 6.47714 6.97714 2 12.5 2C18.0229 2 22.5 6.47714 22.5 12ZM11.3433 17.2949L18.7627 9.87556C19.0146 9.62363 19.0146 9.21512 18.7627 8.96319L17.8503 8.05081C17.5983 7.79883 17.1898 7.79883 16.9379 8.05081L10.8871 14.1015L8.06214 11.2766C7.8102 11.0246 7.40169 11.0246 7.14972 11.2766L6.23734 12.189C5.9854 12.4409 5.9854 12.8494 6.23734 13.1013L10.4309 17.2949C10.6829 17.5469 11.0913 17.5469 11.3433 17.2949V17.2949Z" fill="#0CF73F"/>
                </svg>
                </div>
              </div>
              <h3 style={{marginTop: '-5px', alignSelf: 'stretch', color: '#262626', fontSize: '16px', fontFamily: 'Inter', fontStyle: 'normal', fontWeight: '600', lineHeight: '150%'}}>Consignado</h3>
              <p style={{ marginTop: '-10px', alignSelf: 'stretch', color: '#7A7A7A', fontFamily: 'Inter', fontSize: '16px', fontStyle: 'normal', fontWeight: '400', lineHeight: '150%'}}>National ID e tudo masi sobre</p>
              <button style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', alignSelf: 'stretch', borderRadius: '2222px', background: 'white', color: 'black', border: '1px solid red', padding: '4px 10px 4px 7px', height: '28px', fontSize: '13px', fontStyle: 'normal'}}>Saiba mais</button>
            </div>
          </div> */}

          <div style={{ display: 'flex', width: '155.5px', padding: '12px', flexDirection: 'column', alignItems: 'flex-start', gap: '8px', borderRadius: '8px', background: 'linear-gradient(180deg, rgba(207, 207, 207, 0.26) 0%, rgba(207, 207, 207, 0.00) 100%)' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', alignSelf: 'stretch' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignContent: 'center', width: '100%', height: 'auto' }}>
                <img src='Saly-42.png' style={{ width: '30px' }} />
                <div>
                  <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                    <path d="M22.5 12C22.5 17.5229 18.0229 22 12.5 22C6.97714 22 2.5 17.5229 2.5 12C2.5 6.47714 6.97714 2 12.5 2C18.0229 2 22.5 6.47714 22.5 12ZM11.3433 17.2949L18.7627 9.87556C19.0146 9.62363 19.0146 9.21512 18.7627 8.96319L17.8503 8.05081C17.5983 7.79883 17.1898 7.79883 16.9379 8.05081L10.8871 14.1015L8.06214 11.2766C7.8102 11.0246 7.40169 11.0246 7.14972 11.2766L6.23734 12.189C5.9854 12.4409 5.9854 12.8494 6.23734 13.1013L10.4309 17.2949C10.6829 17.5469 11.0913 17.5469 11.3433 17.2949V17.2949Z" fill="#0CF73F" />
                  </svg>
                </div>
              </div>
              <h3 style={{ marginTop: '-5px', alignSelf: 'stretch', color: '#262626', fontSize: '16px', fontFamily: 'Inter', fontStyle: 'normal', fontWeight: '600', lineHeight: '150%' }}>Feedback</h3>
              <p style={{ marginTop: '-10px', alignSelf: 'stretch', color: '#7A7A7A', fontFamily: 'Inter', fontSize: '16px', fontStyle: 'normal', fontWeight: '400', lineHeight: '150%' }}>Insira o seu feedback do app</p>
              <a onClick={() => setShowModal(true)}>
                <button style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', alignSelf: 'stretch', borderRadius: '2222px', background: 'white', color: 'black', border: '1px solid red', padding: '4px 10px 4px 7px', height: '28px', fontSize: '13px', fontStyle: 'normal' }}>Saiba mais</button>
              </a>
            </div>
          </div>

          <div style={{ display: 'flex', width: '155.5px', padding: '12px', flexDirection: 'column', alignItems: 'flex-start', gap: '8px', borderRadius: '8px', background: 'linear-gradient(180deg, rgba(207, 207, 207, 0.26) 0%, rgba(207, 207, 207, 0.00) 100%)' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', alignSelf: 'stretch' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignContent: 'center', width: '100%', height: 'auto' }}>
                <img src='saly31.png' style={{ width: '30px' }} />
                <div>
                  <svg xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                    <path d="M22.5 12C22.5 17.5229 18.0229 22 12.5 22C6.97714 22 2.5 17.5229 2.5 12C2.5 6.47714 6.97714 2 12.5 2C18.0229 2 22.5 6.47714 22.5 12ZM11.3433 17.2949L18.7627 9.87556C19.0146 9.62363 19.0146 9.21512 18.7627 8.96319L17.8503 8.05081C17.5983 7.79883 17.1898 7.79883 16.9379 8.05081L10.8871 14.1015L8.06214 11.2766C7.8102 11.0246 7.40169 11.0246 7.14972 11.2766L6.23734 12.189C5.9854 12.4409 5.9854 12.8494 6.23734 13.1013L10.4309 17.2949C10.6829 17.5469 11.0913 17.5469 11.3433 17.2949V17.2949Z" fill="#0CF73F" />
                  </svg>
                </div>
              </div>
              <h3 style={{ marginTop: '-5px', alignSelf: 'stretch', color: '#262626', fontSize: '16px', fontFamily: 'Inter', fontStyle: 'normal', fontWeight: '600', lineHeight: '150%' }}>Fale Conosco</h3>

              <p style={{ marginTop: '-10px', alignSelf: 'stretch', color: '#7A7A7A', fontFamily: 'Inter', fontSize: '16px', fontStyle: 'normal', fontWeight: '400', lineHeight: '150%' }}>Quer tirar alguma dúvida!</p>
              <a href='https://api.whatsapp.com/send/?phone=1147651770&text&type=phone_number&app_absent=0'>
                <button style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', alignSelf: 'stretch', borderRadius: '2222px', background: 'white', color: 'black', border: '1px solid red', padding: '4px 10px 4px 7px', height: '28px', fontSize: '13px', fontStyle: 'normal' }}>Fale conosco</button>
              </a>
            </div>
          </div>
        </IonList>

        <IonModal 
  isOpen={showModal} 
  onDidDismiss={() => setShowModal(false)}
  className="feedback-modal"
  breakpoints={[0, 1, 0.8]}
  initialBreakpoint={0.5}
>
  <IonHeader className="ion-no-border">
    <IonToolbar>
      <IonButtons slot="end">
        <IonButton onClick={() => setShowModal(false)}>
          <IonIcon icon={close} />
        </IonButton>
      </IonButtons>
      <IonTitle className="ion-text-center">Seu Feedback</IonTitle>
    </IonToolbar>
    <div className="feedback-container">
      <IonText color="medium">
        <p className="ion-text-center">
          Sua opinião é muito importante para nós. Por favor, compartilhe seu feedback abaixo.
        </p>
      </IonText>

      <div className="textarea-wrapper ion-margin-vertical">
        <IonTextarea
          placeholder="Digite seu feedback aqui..."
          value={feedback}
          onIonChange={e => setFeedback(e.detail.value)}
          autoGrow
          className="custom-textarea"
          rows={4}
          maxlength={500}
        />
      </div>

      <div className="button-container">
        <IonButton 
          expand="block" 
          onClick={handleSubmit}
          className="submit-button"
          strong
        >
          <IonIcon icon={sendOutline} slot="start" />
          Enviar Feedback
        </IonButton>

        <IonButton 
          expand="block" 
          fill="outline" 
          onClick={() => setShowModal(false)}
          className="cancel-button"
        >
          Cancelar
        </IonButton>
      </div>
    </div>
  </IonHeader>

  <IonContent className="ion-padding">
 
  </IonContent>
</IonModal>
      </IonContent>
    </>
  );
}

export default Example;
