import React, { useEffect, useRef, useState } from "react";
import {
    IonButton,
    IonModal,
    IonHeader,
    IonContent,
    IonToolbar,
    IonTitle,
    IonPage,
    IonInput,
    IonItem,
    IonToast,
} from "@ionic/react";
import { IonCard, IonCardContent, IonCardHeader, IonCardSubtitle, IonCardTitle } from '@ionic/react';
import ModalButton from "../../components/Buttons/Button";
import './Proposta1.css';
import { Link } from "react-router-dom";
function Proposta1() {
    const modal = useRef<HTMLIonModalElement>(null);
    const [user_login, setUser_login] = useState("");
    const [user_pass, setUser_pass] = useState("");
    const [showToast, setShowToast] = useState(false);
    const [toastMessage, setToastMessage] = useState("");
    const [propostas, setPropostas] = useState([]);
    const [cliente, setCliente] = useState("");
    const [link, setLink] = useState(''); // Estado para armazenar o link
    const [timeline, setTimeline] = useState([]);
    const [modalOpen, setModalOpen] = useState(false);
    const [selectedProposta, setSelectedProposta] = useState(null);
    const [activeTab, setActiveTab] = useState("detalhes");
    const [checkProposta, setCheckProposta] = useState("");
    const [isLoading, setIsLoading] = useState(true);


    const [formData, setFormData] = useState<any>(() => {
        return JSON.parse(localStorage.getItem('dadosUsuario') || '{}') || {
            pessoa_cpf: ''
        };
    });

    


    const cpf = formData.pessoa_cpf;

    useEffect(() => {
        const fetchProposta = async () => {
            try {
                const response = await fetch(`https://phapp.phng.com.br/api/propostaCpf/${cpf}`, {
                    method: "GET",
                });

                if (response.ok) {
                    const data = await response.json();
                    setCliente(data.cliente);
                    setPropostas(data.propostas);
                    setIsLoading(false);
                } else {
                    console.error("Erro ao buscar propostas.");
                }
            } catch (error) {
                console.error("Erro ao buscar dados do usuário:", error);
            }
        };

        fetchProposta();
    }, []);


    const propostaDetail = async (idProposta) => {
        try {
            const response = await fetch(`https://phapp.phng.com.br/api/propostaStatus2/${idProposta}`);
            const data = await response.json();

            if (response.ok) {
                // Lógica para manipular o sucesso
                // Parse da string JSON no campo 'link'
                const linkData = JSON.parse(data.link);

                // Verificando se a resposta contém a propriedade 'resposta'
                if (data?.resposta) {

                    // Verificando a timeline, que está dentro de 'resposta'
                    if (data.resposta.resposta.timeline) {
                        const timeline = data.resposta.resposta.timeline;
                        if (Array.isArray(timeline) && timeline.length > 0) {
                            console.log("Timeline encontrada:", timeline);
                            setTimeline(timeline); // Atualizando o estado com a timeline
                        } else {
                            console.log("Timeline está vazia ou não é um array válido.");
                        }
                    } else {
                        console.log("Propriedade 'timeline' não encontrada.");
                    }
                } else {
                    console.log("Propriedade 'resposta' não encontrada.");
                }


                // Acessando o URL
                const link = linkData.resposta[0]?.url;
                const propostaLink = linkData.resposta[0]?.url;
                setLink(propostaLink);

                const prop = data.resposta.resposta;
                console.log(data.resposta);
                setSelectedProposta(prop);
                setActiveTab("detalhes"); // Sempre redefinir a aba ao abrir
                setModalOpen(true);

            } else {
                // Lógica para lidar com o erro
                console.error("Erro ao obter os detalhes da proposta:", data);
            }
        } catch (error) {
            console.error("Erro ao fazer a requisição:", error);
        }
    };

    console.log("Dados do selected proposta: " + selectedProposta);

    const closeModal = () => {
        setModalOpen(false);
        setSelectedProposta(null);
    };


    const openModal = async (proposta) => {
        setSelectedProposta(proposta);
        setModalOpen(true);
    }

    return (
        <>
            <IonPage>
                <IonContent scrollY>
                    <div className="custom-proposta1-content">

                        <nav className="custom-proposta1-navbar">
                            <Link to="/dashboard">
                                <button>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                        <path d="M12.9422 15.8078C13.0003 15.8659 13.0463 15.9348 13.0777 16.0107C13.1092 16.0866 13.1254 16.1679 13.1254 16.25C13.1254 16.3321 13.1092 16.4135 13.0777 16.4893C13.0463 16.5652 13.0003 16.6341 12.9422 16.6922C12.8841 16.7503 12.8152 16.7963 12.7393 16.8278C12.6634 16.8592 12.5821 16.8754 12.5 16.8754C12.4179 16.8754 12.3366 16.8592 12.2607 16.8278C12.1848 16.7963 12.1159 16.7503 12.0578 16.6922L5.80782 10.4422C5.74971 10.3842 5.70361 10.3152 5.67215 10.2393C5.6407 10.1635 5.62451 10.0821 5.62451 10C5.62451 9.91788 5.6407 9.83655 5.67215 9.76067C5.70361 9.6848 5.74971 9.61587 5.80782 9.55782L12.0578 3.30782C12.1751 3.19055 12.3342 3.12466 12.5 3.12466C12.6659 3.12466 12.8249 3.19055 12.9422 3.30782C13.0595 3.4251 13.1254 3.58416 13.1254 3.75001C13.1254 3.91586 13.0595 4.07492 12.9422 4.1922L7.1336 10L12.9422 15.8078Z" fill="#878787" />
                                    </svg>
                                </button>
                            </Link>

                            <h3>Proposta</h3>
                        </nav>

                        <div className="custom-proposta1-navbar" style={{ textAlign: 'center', display: 'flex', justifyContent: 'center'}}>
                            <h4 style={{ textAlign: 'center', display: 'flex', justifyContent: 'center', fontSize: '28px'}}>Meus contratos</h4>
                        </div>

                        {/*                     <div className="custom-proposta1-card">
 */}                     {/*    <img src="/proposta.png" className="cardimg" /> */}

                      {/*   <div className="custom-proposta1-status">
                            <div>
                                <h3>PH Negócios</h3>
                                <p>Contratos</p>
                            </div>

                            <h3>Status</h3>
                        </div> */}
                        {/*                     </div>
 */}
                        {/*    <div className="custom-proposta1-grid">
                        <button><img src="/Proposta1Card2.png"/></button>
                        <button><img src="/Proposta1Card2.png"/></button>
                        <button><img src="/Proposta1Card2.png"/></button>
                        </div> */}

                      {/*   <div className="custom-proposta1-navbar">
                            <h3>Contratos </h3>
                            <img src="/PHlogo.png" style={{ width: '40px' }} />

                        </div> */}

                        <p className="custom-proposta1-describe">Visualize todos os seus contratos aqui e acompanhe os seus status.</p>

                        {isLoading ? (
                <div className="loader-container">
                    <div className="loader"></div>
                    <p style={{ textAlign: 'center' }}>Ainda não encontramos nenhuma proposta sua em nosso sistema</p>
                </div>
            ) : (
                propostas.map((proposta, index) => (
                    <div 
                        key={proposta.hash} 
                        onClick={() => propostaDetail(proposta.hash)} 
                        className="custom-proposta1-proposta" 
                        style={{ background: 'white', boxShadow: '0px 4px 30px 0px rgba(54, 41, 183, 0.07)' }}
                    >
                        <div>
                            <h3 style={{ color: "red", textAlign: 'center' }}>Valor Liberado</h3>
                            <p style={{ marginTop: '-5px', fontFeatureSettings: 'dilig on', fontFamily: 'DM Sans', fontSize: '38px', fontStyle: 'normal', fontWeight: '700', lineHeight: 'normal' }}>
                                R$ {parseFloat(proposta.valorLiquido).toFixed(2)}
                            </p>
                        </div>
                        <div className="custom-proposta1-item">
                            <h3 style={{ color: "black" }}>Valor solicitado</h3>
                            <p>R$ {parseFloat(proposta.valorBruto).toFixed(2)}</p>
                        </div>
                        <div className="custom-proposta1-item">
                            <h3 style={{ color: "black" }}>Status</h3>
                            <p>{proposta.status}</p>
                        </div>
                    </div>
                ))
            )}

                        {/* Exibindo o link abaixo da lista de propostas */}
                        {/* Modal */}
                        <IonModal  ref={modal} trigger="open-modal" initialBreakpoint={1} breakpoints={[0, 1]} isOpen={modalOpen} onDidDismiss={closeModal}>
                        <div className="block2">
        <h3>Detalhes da Proposta</h3>
        
        <div className="tabs">
          <button
            onClick={() => setActiveTab("detalhes")}
            className={activeTab === "detalhes" ? "active" : ""}
          >
            Detalhes
          </button>
          <button
            onClick={() => setActiveTab("timeline")}
            className={activeTab === "timeline" ? "active" : ""}
          >
            Status
          </button>
          <button
            onClick={() => setActiveTab("link")}
            className={activeTab === "link" ? "active" : ""}
          >
            Link
          </button>
        </div>

        {selectedProposta && (
          <div className="modal-content">
            {activeTab === "detalhes" && (
              <div className="details-container">
                <div className="details-item">
                  <div className="details-label">Operação</div>
                  <div className="details-value">{selectedProposta.creditNoteNo}</div>
                </div>

                <div className="details-item">
                  <div className="details-label">Valor Solicitado</div>
                  <div className="details-value">
                    {selectedProposta.amortization.initialValue
                      ? new Intl.NumberFormat("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        }).format(selectedProposta.amortization.initialValue / 100)
                      : "N/A"}
                  </div>
                </div>

                <div className="details-item">
                  <div className="details-label">Valor Liberado</div>
                  <div className="details-value success">
                    {selectedProposta.amortization.liquidValue
                      ? new Intl.NumberFormat("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                        }).format(selectedProposta.amortization.liquidValue / 100)
                      : "N/A"}
                  </div>
                </div>

                <div className="details-item">
                  <div className="details-label">Antecipações solicitadas</div>
                  <div className="details-value">
                    {selectedProposta.amortization.termInMonths ?? "N/A"} meses
                  </div>
                </div>

                <div className="details-item">
                  <div className="details-label">Status</div>
                  <div className="details-value">
                    {selectedProposta.statusDisplay ?? "N/A"}
                  </div>
                </div>
              </div>
            )}

            {activeTab === "timeline" && (
              <div className="timeline-container">
                {timeline.map((item, index) => (
                  <div key={index} className="timeline-item">
                    <div className="timeline-marker">
                      <div className={`marker ${item.completed ? 'completed' : ''}`}>
                        {item.completed && (
                          <svg className="check-icon" viewBox="0 0 24 24">
                            <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
                          </svg>
                        )}
                      </div>
                      {index < timeline.length - 1 && <div className="timeline-line"></div>}
                    </div>
                    <div className="timeline-content">
                      <h4>{item.name}</h4>
                      <p className="timeline-date">
                        {new Date(item.createdAt).toLocaleString("pt-BR")}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeTab === "link" && link && (
              <div className="link-container">
                <h4 className="link-title">Link da Proposta</h4>
                <a
                  href={link}
                  className="link-button"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Clique aqui para acessar
                </a>
              </div>
            )}
          </div>
        )}
                                </div>
                        </IonModal>


                        <Link to="/simulation3">
                            <button className="custom-button-modal3">
                                Quero Simular
                            </button>
                        </Link>
                    </div>
                </IonContent>
            </IonPage>
        </>
    );
}

export default Proposta1;
